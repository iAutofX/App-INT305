package com.kyleclark.thehungrydeveloper;


import androidx.annotation.NonNull;

public class Dish {

    //The 'State' are the things the class knows about itself.
    String title;
    String description;
    double price;

    // Constructor
    Dish(String title, String description, double price) {
        this.title = title; // common to use the same name but it could be anything
        this.description = description;
        this.price = price;
    }


    @NonNull
    @Override
    public String toString() {
        return "Dish{ " +
                "Title: '" + title + "'" + "\nDescription: '" + description + "'" + "\nPrice: $" + price + "}";
    }
}
