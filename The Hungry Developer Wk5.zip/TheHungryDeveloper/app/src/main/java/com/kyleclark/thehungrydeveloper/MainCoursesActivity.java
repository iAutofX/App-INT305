package com.kyleclark.thehungrydeveloper;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MainCoursesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main_courses);

        ListView mainCoursesList = findViewById(R.id.list_view_main_courses);

        Dish[] mainCourses = {
                new Dish("Black pepper and chickpea vindaloo", "Hot dindaloo made with hot black pepper and fresh chickpea", 13.99),
                new Dish("Goji berry and cauliflower salad", "A crisp salad featuring fresh goji berry and cauliflower", 12.99),
                new Dish("Thai basil and mulberry salad", "A crisp salad featuring fresh thai basil and mulberry", 14.99),
                new Dish("Onion and apple ciabatta", "Warm ciabatta filled with caramalised onion and fresh apple", 12.99),
                new Dish("Onion and olive bread", "Crunchy bread made with baby onion and olive", 11.99),
                new Dish("Onion and mustard soup", "Dried onion and French mustard combined into smooth soup", 12.99),
                new Dish("Samphire and rocket salad", "Samphire and fresh rocket served on a bed of lettuce", 15.99),
                new Dish("Cocoa and chicory salad", "Cocoa and chicory served on a bed of lettuce", 16.99),
                new Dish("Cauliflower and squash curry", "Mild curry made with fresh cauliflower and butternut squash", 14.99),
                new Dish("Cauliflower and potato madras", "Medium-hot madras made with fresh cauliflower and new potato", 13.99),
        };

        ArrayAdapter<Dish> dishAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, mainCourses);

        mainCoursesList.setAdapter(dishAdapter);


    }

}
