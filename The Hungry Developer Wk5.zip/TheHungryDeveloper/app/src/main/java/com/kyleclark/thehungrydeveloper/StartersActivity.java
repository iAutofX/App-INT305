package com.kyleclark.thehungrydeveloper;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.List;

public class StartersActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_starters);

        ListView startersList = findViewById(R.id.list_view_starters);

//        Dish dishOne = new Dish("Mushroom and tofu maki", "Mushroom seaweed sushi rice stuff", 9.99);


        Dish[] dishes = {
                new Dish("Mushroom and tofu maki", "Mushroom seaweed sushi rice stuff", 9.99),
                new Dish("Egg and avocado uramaki", "Pasta in a sauce made from eggs and avocado", 11.99),
                new Dish("Melon and lemon soup", "Fresh melon and lemon combined into creamy soup", 11.99),
                new Dish("Coconut and chocolate mousse", "A creamy mousse made with fresh coconut and milk chocolate", 8.99),
                new Dish("Spinach and cabbage wontons", "Thin wonton cases stuffed with fresh spinach and chinese cabbage", 7.99),
                new Dish("Broccoli and cucumber soup", "Fresh broccoli and cucumber combined into creamy soup", 8.99),
                new Dish("Chilli and aubergine dip", "A dip made from scotch bonnet chilli and fresh aubergine", 9.99),
                new Dish("Chickpea and chilli gyoza", "Thin pastry cases stuffed with fresh chickpea and green chilli", 6.99),
                new Dish("Sprout and pineapple soup", "Fresh sprout and pineapple combined into creamy soup", 8.99),
                new Dish("Egusi and borscht soup", "Egusi and borscht combined into creamy soup", 12.99)

        };

//        String[] dishes = {
//
//                "Egg and avocado uramaki",
//                "Melon and lemon soup",
//                "Coconut and chocolate mousse",
//                "Spinach and cabbage wontons",
//                "Broccoli and cucumber soup",
//                "Chilli and aubergine dip",
//                "Chickpea and chilli gyoza",
//                "Sprout and pineapple soup",
//                "Egusi and borscht soup",
//                "Aubergine and egg sushi",
//                "Artichoke and mustard soup",
//                "Peppercorn and tamarind soup",
//                "Parsley and celeriac parcels",
//                "Pasta and broccoli soup",
//                "Potato and courgette soup",
//                "Chickpea and cabbage parcels",
//                "Coriander and peppercorn gyoza",
//                "Pear and chestnut soup",
//                "Pesto and garam masala parcels"
//        };

        // context, layout, array
        ArrayAdapter<Dish> dishesAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, dishes);

        startersList.setAdapter(dishesAdapter);

    }
}